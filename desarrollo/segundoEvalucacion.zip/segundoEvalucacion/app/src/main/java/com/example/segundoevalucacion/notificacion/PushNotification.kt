package com.example.segundoevalucacion.notificacion


data class PushNotification(var data: NotificacionModel,
                            var to:String)
