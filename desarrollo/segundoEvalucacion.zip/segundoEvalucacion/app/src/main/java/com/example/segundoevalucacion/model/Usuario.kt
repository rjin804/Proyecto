package com.example.segundoevalucacion.model

import java.io.Serializable

data class Usuario(var nombre : String?=null, var apellidos : String?=null, var Longitud : String?=null, var latitud : String?=null):
    Serializable {

}
