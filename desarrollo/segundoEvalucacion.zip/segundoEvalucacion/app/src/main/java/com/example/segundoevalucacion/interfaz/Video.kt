package com.example.segundoevalucacion.interfaz

/**
 * Video
 *
 * @constructor Create empty Video
 */
interface Video {
    public fun video(ac: Boolean)
}