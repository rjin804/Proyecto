package com.example.segundoevalucacion.interfaz

/**
 * Brillo
 *
 * @constructor Create empty Brillo
 */
interface Brillo {
    public fun brillo(ac: Boolean)

}