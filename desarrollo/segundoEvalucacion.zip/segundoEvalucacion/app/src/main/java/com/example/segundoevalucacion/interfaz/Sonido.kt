package com.example.segundoevalucacion.interfaz

/**
 * Sonido
 *
 * @constructor Create empty Sonido
 */
interface Sonido {
    public fun sonido(ac: Boolean)
}