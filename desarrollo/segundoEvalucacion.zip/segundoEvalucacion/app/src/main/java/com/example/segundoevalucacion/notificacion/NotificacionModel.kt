package com.example.segundoevalucacion.notificacion

data class NotificacionModel(var titulo:String, var mensaje:String)
