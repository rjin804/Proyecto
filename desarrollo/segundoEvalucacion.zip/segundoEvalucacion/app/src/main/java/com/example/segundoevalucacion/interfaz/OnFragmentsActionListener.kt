package com.example.segundoevalucacion.interfaz

/**
 * On fragments action listener
 *
 * @constructor Create empty On fragments action listener
 */
interface OnFragmentsActionListener {
    public fun onClickBotonMenu(btn: Int)
}